MODELAGEM DE UM PROBLEMA
A base de dados para construção do grafo proposto e utilizado no projeto foi retirada do site "www.kaggle.com", a base
contém informações de mais de 20.000 partidas de xadrez ocorridas no site "lichess.org", o dataset possui informações
sobre movimentos executados pelos jogadores, número de vitórias, ranqueamento dentro da plataforma e informações como
tempo de início e fim das partidas. Para o fim de nosso trabalho pegamos as informações sobre as partidas,
especificamente quais jogadores se enfrentaram em cada uma das partidas, o objetivo era descobrir se a maioria dos
jogadores participavam de partidas contra pessoas aleatórias, que não conheciam, ou se tinham a tendência de jogar
sempre com as mesmas pessoas dentro do círculo de amigos. Após fazer o uso do coeficiente de agrupamento local de todos
os vértices, chegamos a conclusão que 99,6% dos jogadores procuram partidas de forma aleatória e somente 0,4% tende a
jogar sempre com o mesmo grupo, além disso isolamos os 5 vértices com maior coeficiente e realizamos um estudo em suas
adjacências, comprovando os resultados mencionados anteriormente.